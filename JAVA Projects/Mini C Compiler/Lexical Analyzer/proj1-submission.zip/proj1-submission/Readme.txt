1. go to proj1-submission directory

2. compile Lexer.flex with command:

java -jar jflex-1.6.1.jar Lexer.flex

3. Compile other java files

5. Run command for soultion texts

java Program test1.minc > solu1.txt