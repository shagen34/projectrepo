public class Parser
{
    public static final int MAIN        = 10;
    public static final int PRINT       = 11;
    public static final int INT         = 13;
    public static final int BEGIN       = 30;
    public static final int END         = 31;
    public static final int LPAREN      = 33;
    public static final int RPAREN      = 34;
    public static final int ASSIGN      = 38;
    public static final int PLUS        = 41;
    public static final int MUL         = 43;
    public static final int SEMI        = 47;
    public static final int INT_LIT     = 55;
    public static final int IDENT       = 58;

    public Parser(java.io.Reader r) throws java.io.IOException
    {
        this.lexer    = new Lexer(r, this);
    }

    Lexer   lexer;
    public ParserVal yylval;

    public int yyparse() throws java.io.IOException
    {
        while ( true )
        {
            int token = lexer.yylex();
            if(token == 0)
            {
                // EOF is reached
                return 0;
            }
            if(token == -1)
            {
                // error
                return -1;
            }

            Object attr = yylval.obj;
            System.out.println("<token-id:" + token + ", token-attr:" + attr + ", lineno:" + lexer.lineno + ">");
        }
    }
}
