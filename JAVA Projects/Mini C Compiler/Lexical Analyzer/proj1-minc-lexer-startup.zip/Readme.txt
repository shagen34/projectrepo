﻿
1. goto "src" directory

2. copy jflex-1.6.1.jar into src directory

3. compile Lexer.jflex as follows:

java -jar jflex-1.6.1.jar Lexer.flex

4. compile all java files

5. run program and capture its output as follows:

java Program test1.minc > solu1.txt
