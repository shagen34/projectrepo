public class Lex
{
    public static final int EOF        =  0;

    String input;
    int    loc;
    public String _yytext;
    public String yytext() { return _yytext; }
    private Parser yyparser;
    public Lex(java.io.Reader reader, Parser yyparser) throws java.io.IOException
    {
        StringBuilder builder = new StringBuilder();
        {
            int numChars;
            char[] cbuf = new char[2048];
            while ((numChars = reader.read(cbuf)) >= 0) {
                builder.append(cbuf, 0, numChars);
            }
        }
        this.input = builder.toString();
        this.loc = 0;
        this.yyparser = yyparser;
    }
    public int yylex()
    {
        while(loc < input.length())
        {
            String input_loc = input.substring(loc);
            if(input_loc.startsWith(" "    )) { loc ++; continue; }                     // WHITESPACE
            if(input_loc.startsWith("\t"   )) { loc ++; continue; }                     // WHITESPACE
            if(input_loc.startsWith("\n"   )) { loc ++; continue; }                     // NEWLINE

            if(input_loc.startsWith("main" )) { loc += 4; _yytext = "main" ; yyparser.yylval = new ParserVal(_yytext); return Parser.MAIN  ; }
            if(input_loc.startsWith("{"    )) { loc += 1; _yytext = "{"    ; yyparser.yylval = new ParserVal(_yytext); return Parser.BEGIN ; }
            if(input_loc.startsWith("}"    )) { loc += 1; _yytext = "}"    ; yyparser.yylval = new ParserVal(_yytext); return Parser.END   ; }
            if(input_loc.startsWith("print")) { loc += 5; _yytext = "print"; yyparser.yylval = new ParserVal(_yytext); return Parser.PRINT ; }
            if(input_loc.startsWith("("    )) { loc += 1; _yytext = "("    ; yyparser.yylval = new ParserVal(_yytext); return Parser.LPAREN; }
            if(input_loc.startsWith(")"    )) { loc += 1; _yytext = ")"    ; yyparser.yylval = new ParserVal(_yytext); return Parser.RPAREN; }
            if(input_loc.startsWith("="    )) { loc += 1; _yytext = "="    ; yyparser.yylval = new ParserVal(_yytext); return Parser.ASSIGN; }
            if(input_loc.startsWith("+"    )) { loc += 1; _yytext = "+"    ; yyparser.yylval = new ParserVal(_yytext); return Parser.PLUS  ; }
            if(input_loc.startsWith(";"    )) { loc += 1; _yytext = ";"    ; yyparser.yylval = new ParserVal(_yytext); return Parser.SEMI  ; }

            char char_loc = input.charAt(loc);
            if('0' <= char_loc && char_loc <= '9')
            {
                _yytext = "";
                while ('0' <= char_loc && char_loc <= '9')
                {
                    _yytext += input.charAt(loc);
                    loc++;
                    char_loc = input.charAt(loc);
                }
                yyparser.yylval = new ParserVal(_yytext); 
                return Parser.NUM;  // NUM
            }
            if ('a' <= char_loc && char_loc <= 'z')
            {
                _yytext = "";
                while ('a' <= char_loc && char_loc <= 'z')
                {
                    _yytext += input.charAt(loc);
                    loc++;
                    char_loc = input.charAt(loc);
                }

                if (yyparser.SymbolTable().containsKey(_yytext) == false)
                    yyparser.SymbolTable().put(_yytext, 0);

                yyparser.yylval = new ParserVal(_yytext); 
                return Parser.ID;  // ID
            }

            loc ++;
        }
        return EOF;
    }
}
