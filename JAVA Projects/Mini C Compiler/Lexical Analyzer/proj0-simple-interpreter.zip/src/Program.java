public class Program {
	public static void main(String[] args) throws Exception
    {
        //java.io.Reader r = new java.io.StringReader
        //("main()\n"
        //+"{\n"
        //+"    x = 1;\n"
        //+"    x = x + 1;\n"
        //+"    x = x + 1;\n"
        //+"    3.141592 if else while bool int float  true false == != < > <= >= - * /;\n"
        //+"    print x;\n"
        //+"}\n"
        //);

        if(args.length < 0)
            return;
        java.io.Reader r = new java.io.FileReader(args[0]);

        Compiler compiler = new Compiler(r);
        compiler.Compile();
	}
}
