1. move to the source directory

cd src

2. compile all java files

javac *.java

3. run with test1.minc as input

java Program test1.minc

